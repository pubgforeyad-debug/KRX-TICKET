const {
Client,
GatewayIntentBits,
ChannelType,
PermissionsBitField,
ActionRowBuilder,
ButtonBuilder,
ButtonStyle,
EmbedBuilder,
Events
} = require("discord.js");

require("dotenv").config();
const fs = require("fs");

const client = new Client({

intents:[

GatewayIntentBits.Guilds,
GatewayIntentBits.GuildMessages,
GatewayIntentBits.GuildMembers,
GatewayIntentBits.MessageContent,
GatewayIntentBits.DirectMessages

]

});


// =========================
// CONFIG
// =========================


const configPath = "./config.json";

let config = {};
try{
  config = require(configPath);
}catch{
  config = {};
}

function saveConfig(){
  fs.writeFileSync(
    configPath,
    JSON.stringify(config,null,2)
  );
}

// =========================
// HELPERS
// =========================

function getStaffRoles(){
  return [
    config.STAFF_ROLE,
    config.HIGH_ROLE
  ].filter(Boolean);
}

function hasStaffPermission(message){
  if(!message.guild || !message.member) return false;

  if(message.author.id === message.guild.ownerId) return true;

  if(message.member.permissions.has(
    PermissionsBitField.Flags.Administrator
  )){
    return true;
  }

  return getStaffRoles().some(roleId =>
    message.member.roles.cache.has(roleId)
  );
}


// =========================
// حفظ IDs من داخل ديسكورد
// =========================

client.on("messageCreate", async message=>{

  if(message.author.bot || !message.guild) return;

  const isOwner =
    message.author.id === message.guild.ownerId;

  const isAdministrator =
    message.member.permissions.has(
      PermissionsBitField.Flags.Administrator
    );

  if(!isOwner && !isAdministrator) return;

  if(message.content.startsWith("!idstaff ")){

    const id =
      message.content.trim().split(/\s+/)[1];

    const role =
      message.guild.roles.cache.get(id);

    if(!role){
      return message.reply(
        "❌ اكتب ID رتبة استف صحيحة.\nمثال: `!idstaff 123456789`"
      );
    }

    config.STAFF_ROLE = role.id;
    saveConfig();

    return message.reply(
      `✅ تم حفظ رتبة الاستف: ${role}`
    );
  }


  if(message.content.startsWith("!idhigh ")){

    const id =
      message.content.trim().split(/\s+/)[1];

    const role =
      message.guild.roles.cache.get(id);

    if(!role){
      return message.reply(
        "❌ اكتب ID رتبة الإدارة العليا صحيحة.\nمثال: `!idhigh 123456789`"
      );
    }

    config.HIGH_ROLE = role.id;
    saveConfig();

    return message.reply(
      `✅ تم حفظ رتبة الإدارة العليا: ${role}`
    );
  }


  if(message.content.startsWith("!idticket ")){

    const id =
      message.content.trim().split(/\s+/)[1];

    const category =
      message.guild.channels.cache.get(id);

    if(!category || category.type !== ChannelType.GuildCategory){
      return message.reply(
        "❌ اكتب ID كاتيجوري صحيح.\nمثال: `!idticket 123456789`"
      );
    }

    config.TICKET_CATEGORY = category.id;
    saveConfig();

    return message.reply(
      `✅ تم حفظ كاتيجوري التذاكر: **${category.name}**`
    );
  }

});


// =========================
// POINTS
// =========================

let points = {};

if(fs.existsSync("./points.json")){

points =
JSON.parse(
fs.readFileSync("./points.json","utf8")
);

}


function savePoints(){

fs.writeFileSync(
"./points.json",
JSON.stringify(points,null,2)
);

}


// =========================
// SHOP
// =========================

let shop=[];

if(fs.existsSync("./shop.json")){

shop =
JSON.parse(
fs.readFileSync("./shop.json","utf8")
);

}


function saveShop(){

fs.writeFileSync(
"./shop.json",
JSON.stringify(shop,null,2)
);

}


// =========================
// READY
// =========================

client.once("ready",()=>{

console.log(
`✅ ${client.user.tag} Online`
);

});


// =========================
// SETUP PANELS
// =========================


client.on("messageCreate",async message=>{


if(message.author.bot)return;


// ===== APPLY PANEL =====


if(message.content==="!setup1"){


const embed =
new EmbedBuilder()

.setColor("Blue")

.setTitle("📝 تقديم الإدارة | KRX")

.setDescription(
"اضغط الزر لفتح تذكرة التقديم."
)

.setTimestamp();



const row =
new ActionRowBuilder()

.addComponents(

new ButtonBuilder()

.setCustomId("apply_ticket")

.setLabel("📝 تقديم")

.setStyle(ButtonStyle.Success)

);



message.channel.send({

embeds:[embed],

components:[row]

});

}



// ===== SUPPORT PANEL =====


if(message.content==="!setup2"){


const embed =
new EmbedBuilder()

.setColor("Blurple")

.setTitle("🎧 الدعم الفني | KRX")

.setDescription(
"اضغط الزر لفتح تذكرة الدعم."
)

.setTimestamp();



const row =
new ActionRowBuilder()

.addComponents(

new ButtonBuilder()

.setCustomId("support_ticket")

.setLabel("🎧 دعم")

.setStyle(ButtonStyle.Primary)

);



message.channel.send({

embeds:[embed],

components:[row]

});


}


});
// =========================
// فتح التذاكر
// =========================

client.on(Events.InteractionCreate, async interaction => {

  if(!interaction.isButton()) return;
  if(!["apply_ticket","support_ticket"].includes(interaction.customId)) return;

  const isApply = interaction.customId === "apply_ticket";
  const type = isApply ? "تقديم" : "دعم";

  let roles = getStaffRoles();

  if(!config.STAFF_ROLE && !config.HIGH_ROLE){
    return interaction.reply({
      content:"❌ لم يتم تحديد رتب الإدارة بعد. استخدم `!idstaff ID` و `!idhigh ID` أولاً.",
      ephemeral:true
    });
  }

  if(!config.TICKET_CATEGORY){
    return interaction.reply({
      content:"❌ لم يتم تحديد كاتيجوري التذاكر بعد. استخدم `!idticket ID` أولاً.",
      ephemeral:true
    });
  }

  // تجاهل أي Role ID غير موجود في السيرفر بدل ما يفشل إنشاء التذكرة بالكامل
  roles = roles.filter(roleId =>
    interaction.guild.roles.cache.has(roleId)
  );

  await interaction.deferReply({ ephemeral:true });

  try{

    const oldTicket = interaction.guild.channels.cache.find(
      c => c.topic === interaction.user.id
    );

    if(oldTicket){
      return interaction.editReply(
        `❌ لديك تذكرة مفتوحة بالفعل ${oldTicket}`
      );
    }

    // لو الـ Category ID غير صحيح، افتح التذكرة بدون Category بدل ما يتوقف البوت
    let parent = null;

    if(config.TICKET_CATEGORY){
      const category = interaction.guild.channels.cache.get(
        config.TICKET_CATEGORY
      );

      if(category && category.type === ChannelType.GuildCategory){
        parent = category.id;
      }
    }

    const permissionOverwrites = [
      {
        id: interaction.guild.id,
        deny: [PermissionsBitField.Flags.ViewChannel]
      },
      {
        id: interaction.user.id,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
          PermissionsBitField.Flags.AttachFiles
        ]
      },
      ...roles.map(roleId => ({
        id: roleId,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
          PermissionsBitField.Flags.AttachFiles
        ]
      }))
    ];

    const safeUsername = interaction.user.username
      .toLowerCase()
      .replace(/[^a-z0-9_\-\u0600-\u06FF]/g,"-")
      .slice(0,40);

    const ticket = await interaction.guild.channels.create({
      name: `ticket-${type}-${safeUsername}`,
      type: ChannelType.GuildText,
      parent: parent,
      topic: interaction.user.id,
      permissionOverwrites
    });

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("close_ticket")
          .setLabel("🔒 إغلاق")
          .setStyle(ButtonStyle.Danger),

        new ButtonBuilder()
          .setCustomId("delete_ticket")
          .setLabel("🗑️ حذف")
          .setStyle(ButtonStyle.Secondary)
      );

    const mention = roles.map(r => `<@&${r}>`).join(" ");

    const embed = new EmbedBuilder()
      .setColor("Blue")
      .setTitle("🎫 تذكرة جديدة | KRX")
      .setDescription(
`مرحباً ${interaction.user}

اكتب تفاصيل طلبك.

لاستلام التذكرة اكتب:

\`دعم\``
      )
      .setTimestamp();

    await ticket.send({
      content: `${interaction.user}${mention ? ` ${mention}` : ""}`,
      embeds: [embed],
      components: [row],
      allowedMentions: {
        users: [interaction.user.id],
        roles: roles
      }
    });

    await interaction.editReply(
      `✅ تم فتح التذكرة ${ticket}`
    );

  }catch(error){

    console.error("TICKET CREATE ERROR:", error);

    await interaction.editReply(
      "❌ حصل خطأ أثناء فتح التذكرة. تأكد أن البوت لديه Manage Channels وأن IDs في config.json صحيحة."
    ).catch(()=>{});

  }

});


// =========================
// استلام التذكرة + نقاط
// =========================


const claimedTickets = new Map();



client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(message.content!=="دعم")
return;


if(!message.channel.name.startsWith("ticket-"))
return;



const admin = hasStaffPermission(message);



if(!admin){

return message.reply(
"❌ ليس لديك صلاحية."
);

}



if(claimedTickets.has(message.channel.id)){


return message.reply(

`❌ مستلمة بواسطة <@${claimedTickets.get(message.channel.id)}>`

);

}



claimedTickets.set(

message.channel.id,

message.author.id

);



if(!points[message.author.id])

points[message.author.id]=0;



points[message.author.id]+=2;


savePoints();



message.channel.send({

embeds:[

new EmbedBuilder()

.setColor("Green")

.setTitle("✅ تم استلام التذكرة")

.setDescription(

`👤 الإداري:
${message.author}

⭐ حصل على +2 نقطة`

)

]

});



try{

message.author.send(

`🎉 تم استلام تذكرة\n⭐ نقاطك الآن: ${points[message.author.id]}`

);

}catch{}



});
// =========================
// عرض النقاط
// !points
// =========================

client.on("messageCreate",async message=>{

if(message.author.bot)return;

if(message.content!=="!points")
return;


const embed =
new EmbedBuilder()

.setColor("Gold")

.setTitle("⭐ نقاطك")

.setDescription(
`لديك **${points[message.author.id] || 0}** نقطة.`
)

.setTimestamp();



message.reply({

embeds:[embed]

});


});




// =========================
// إضافة نقاط
// +point @user 10
// =========================


client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(!message.content.startsWith("+point "))
return;



const admin = hasStaffPermission(message);



if(!admin)
return message.reply("❌ ليس لديك صلاحية.");



const member =
message.mentions.members.first();


const args = message.content.trim().split(/\s+/);
const amount = Number(args[2]);



if(!member || !Number.isInteger(amount) || amount <= 0)

return message.reply(
"❌ الاستخدام الصحيح:\n+point @user 10"
);



if(!points[member.id])

points[member.id]=0;



points[member.id]+=amount;


savePoints();



message.channel.send(

`✅ تمت إضافة ${amount} نقطة إلى ${member}`

);


});




// =========================
// خصم نقاط
// -point @user 10
// =========================


client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(!message.content.startsWith("-point "))
return;



const admin = hasStaffPermission(message);



if(!admin)
return message.reply("❌ ليس لديك صلاحية.");



const member =
message.mentions.members.first();



const args = message.content.trim().split(/\s+/);
const amount = Number(args[2]);



if(!member || !Number.isInteger(amount) || amount <= 0)

return message.reply(
"❌ الاستخدام الصحيح:\n-point @user 10"
);



if(!points[member.id])

points[member.id]=0;



points[member.id]-=amount;



if(points[member.id]<0)

points[member.id]=0;



savePoints();



message.channel.send(

`➖ تم خصم ${amount} نقطة من ${member}`

);


});




// =========================
// أفضل الإداريين
// $top
// =========================


client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(message.content!="$top")
return;



const top =

Object.entries(points)

.sort((a,b)=>b[1]-a[1])

.slice(0,10);



if(!top.length)

return message.reply(
"❌ لا يوجد نقاط."
);



message.channel.send({

embeds:[

new EmbedBuilder()

.setColor("Gold")

.setTitle("🏆 أفضل الإداريين")

.setDescription(

top.map((x,i)=>

`${i+1}- <@${x[0]}> ⭐ ${x[1]}`

).join("\n")

)

]

});


});




// =========================
// SHOP
// =========================


// !shop

client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(message.content!=="!shop")
return;



if(!shop.length)

return message.reply(
"🛒 الشوب فارغ."
);



const embed =
new EmbedBuilder()

.setColor("Gold")

.setTitle("🛒 متجر النقاط")

.setDescription(

shop.map((x,i)=>

`${i+1}- **${x.name}**
⭐ السعر: ${x.price}`

).join("\n\n")

);



message.reply({

embeds:[embed]

});


});




// =========================
// شراء
// !buy رقم
// =========================


client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(!message.content.startsWith("!buy "))
return;



const id =
Number(message.content.split(" ")[1])-1;



if(!shop[id])

return message.reply(
"❌ المنتج غير موجود."
);



const item=shop[id];


const userPoints =
points[message.author.id] || 0;



if(userPoints < item.price)

return message.reply(
"❌ لا تملك نقاط كافية."
);



points[message.author.id]-=item.price;


savePoints();



message.reply(

`✅ اشتريت **${item.name}**
⭐ تم خصم ${item.price} نقطة`

);


});




// =========================
// إضافة منتج
// صاحب السيرفر
// !addshop اسم السعر
// =========================


client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(!message.content.startsWith("!addshop "))
return;



if(message.author.id !== message.guild.ownerId)

return message.reply(
"❌ هذا الأمر لصاحب السيرفر."
);



const args =
message.content.split(" ").slice(1);



const price =
Number(args.pop());



const name =
args.join(" ");



if(!name || isNaN(price))

return message.reply(
"الاستخدام:\n!addshop VIP 100"
);



shop.push({

name:name,

price:price

});


saveShop();



message.reply(
`✅ تمت إضافة ${name}`
);


});
// =========================
// حذف منتج من الشوب
// !delshop رقم
// =========================

client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(!message.content.startsWith("!delshop "))
return;



if(message.author.id !== message.guild.ownerId)

return message.reply(
"❌ هذا الأمر لصاحب السيرفر فقط."
);



const id =
Number(message.content.split(" ")[1])-1;



if(!shop[id])

return message.reply(
"❌ المنتج غير موجود."
);



const removed =
shop.splice(id,1)[0];


saveShop();



message.reply(
`🗑️ تم حذف ${removed.name} من الشوب.`
);


});




// =========================
// تغيير اسم التذكرة
// !rename
// =========================

client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(!message.content.startsWith("!rename "))
return;



if(!message.channel.name.startsWith("ticket-"))
return;



const admin = hasStaffPermission(message);



if(!admin)

return message.reply(
"❌ ليس لديك صلاحية."
);



const name =
message.content.slice(8).trim();



if(!name)

return message.reply(
"مثال: !rename مشكلة"
);



await message.channel.setName(
`🎫-${name}`
);



message.reply(
"✅ تم تغيير اسم التذكرة."
);


});




// =========================
// حذف التذكرة
// !delete
// =========================


client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(message.content!=="!delete")
return;



if(!message.channel.name.startsWith("ticket-"))
return;



message.reply(
"🗑️ سيتم حذف التذكرة بعد 5 ثواني."
);



setTimeout(()=>{

message.channel.delete()
.catch(()=>{});

},5000);


});




// =========================
// التقييم
// =========================


client.on(
Events.InteractionCreate,
async interaction=>{


if(!interaction.isButton())
return;


if(interaction.customId!=="close_ticket")
return;



const row =
new ActionRowBuilder()

.addComponents(

new ButtonBuilder()
.setCustomId("rate_1")
.setLabel("⭐")
.setStyle(ButtonStyle.Secondary),


new ButtonBuilder()
.setCustomId("rate_2")
.setLabel("⭐⭐")
.setStyle(ButtonStyle.Secondary),


new ButtonBuilder()
.setCustomId("rate_3")
.setLabel("⭐⭐⭐")
.setStyle(ButtonStyle.Secondary),


new ButtonBuilder()
.setCustomId("rate_4")
.setLabel("⭐⭐⭐⭐")
.setStyle(ButtonStyle.Secondary),


new ButtonBuilder()
.setCustomId("rate_5")
.setLabel("⭐⭐⭐⭐⭐")
.setStyle(ButtonStyle.Success)

);



interaction.reply({

embeds:[

new EmbedBuilder()

.setColor("Blue")

.setTitle("⭐ تقييم الخدمة")

.setDescription(
"اختر تقييمك."
)

],

components:[row]

});


});





// =========================
// زر حذف التذكرة
// =========================

client.on(Events.InteractionCreate, async interaction => {

  if(!interaction.isButton()) return;
  if(interaction.customId !== "delete_ticket") return;

  if(!interaction.channel || !interaction.channel.name.startsWith("ticket-")){
    return interaction.reply({
      content:"❌ هذا الزر يعمل داخل التذاكر فقط.",
      ephemeral:true
    });
  }

  const isOwner = interaction.user.id === interaction.guild.ownerId;
  const isAdmin = interaction.member.permissions.has(
    PermissionsBitField.Flags.Administrator
  );

  const memberRoles = interaction.member.roles.cache;
  const staffRole = getStaffRoles()
    .some(roleId => memberRoles.has(roleId));

  if(!isOwner && !isAdmin && !staffRole){
    return interaction.reply({
      content:"❌ ليس لديك صلاحية لحذف التذكرة.",
      ephemeral:true
    });
  }

  await interaction.reply("🗑️ سيتم حذف التذكرة بعد 3 ثواني.");

  setTimeout(() => {
    interaction.channel.delete().catch(()=>{});
  }, 3000);

});


// استقبال التقييم

client.on(
Events.InteractionCreate,
async interaction=>{


if(!interaction.isButton())
return;


if(!interaction.customId.startsWith("rate_"))
return;



const rate =
interaction.customId.split("_")[1];



const channel =
interaction.guild.channels.cache.get(
config.RATING_CHANNEL
);



if(channel){

channel.send({

embeds:[

new EmbedBuilder()

.setColor("Yellow")

.setTitle("⭐ تقييم جديد")

.addFields(

{
name:"العضو",
value:`${interaction.user}`
},

{
name:"التقييم",
value:"⭐".repeat(Number(rate))
}

)

]

});

}



interaction.reply({

content:
`💙 شكراً لتقييمك ${rate}/5`,

ephemeral:true

});



setTimeout(()=>{

interaction.channel.delete()
.catch(()=>{});

},5000);



});




// =========================
// DM
// !dm
// =========================


client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(!message.content.startsWith("!dm"))
return;



if(!message.member.permissions.has(
PermissionsBitField.Flags.Administrator
))

return;



const member =
message.mentions.members.first();



const text =
message.content.split(" ")
.slice(2)
.join(" ");



if(!member || !text)

return message.reply(
"!dm @user الرسالة"
);



try{

await member.send(text);

message.reply(
"✅ تم الإرسال."
);


}catch{

message.reply(
"❌ الخاص مغلق."
);

}


});




// =========================
// DMS للجميع
// =========================


client.on("messageCreate",async message=>{


if(message.author.bot)return;


if(!message.content.startsWith("!dms"))
return;



if(!message.member.permissions.has(
PermissionsBitField.Flags.Administrator
))

return;



const text =
message.content.split(" ")
.slice(1)
.join(" ");



let sent=0;
let failed=0;



for(const member of message.guild.members.cache.values()){


if(member.user.bot)
continue;


try{

await member.send(text);

sent++;

}catch{

failed++;

}


}



message.reply(

`✅ ${sent}
❌ ${failed}`

);


});




// =========================
// تشغيل البوت
// =========================

require("./dashboard")(client, config, saveConfig);

client.login(process.env.TOKEN);