# KRX Bot + Website + Dashboard

## Railway Variables
Keep your existing `TOKEN`, then add:
- `DISCORD_CLIENT_ID=1531918719402377226`
- `DISCORD_CLIENT_SECRET=...`
- `PUBLIC_URL=https://YOUR-RAILWAY-DOMAIN.up.railway.app`
- `SESSION_SECRET=...`
- `NODE_ENV=production`

## Discord Developer Portal
In your Discord application go to OAuth2 > Redirects and add exactly:

`https://YOUR-RAILWAY-DOMAIN.up.railway.app/auth/discord/callback`

It must match `PUBLIC_URL` + `/auth/discord/callback`.

## Files
Upload/replace:
- `index.js`
- `dashboard.js`
- `package.json`
- `public/index.html`
- `public/style.css`

Never put the bot token, client secret, or session secret in GitHub.
